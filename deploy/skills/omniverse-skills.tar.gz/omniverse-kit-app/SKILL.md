---
name: omniverse-kit-app
description: "Build, run, and package a 3D application from scratch with the NVIDIA Omniverse Kit SDK via kit-app-template (OpenUSD, RTX). Use when asked to create/scaffold an Omniverse Kit app, extension, USD viewer/composer/explorer, or a Kit streaming service."
version: "0.1.0"
license: Apache-2.0
platforms: [linux, windows]
tools:
  - Read
  - Shell
  - Write
compatibility: >
  Requires an NVIDIA RTX GPU + recent driver, Linux or Windows (not macOS), Python,
  and internet egress to pull the Kit SDK + extension registry on first build.
  Building/launching renders on RTX (ovrtx); CPU-only hosts can author/validate
  USD but cannot run the app.
metadata:
  author: mac fleet (jordanh) — authored for the GPU nodes
  tags: [omniverse, kit, kit-sdk, openusd, usd, 3d, rtx, application, extension]
  hermes:
    tags: [omniverse, kit, openusd, 3d, rtx, build]
    related_skills: [omniverse-realtime-viewer, omniverse-cad-to-simready, omniverse-usd-performance-tuning]
---

# Build a 3D application with the Omniverse Kit SDK

Use this skill to scaffold, build, run, and package an **OpenUSD** 3D application
using the **Omniverse Kit SDK** via the official
[`NVIDIA-Omniverse/kit-app-template`](https://github.com/NVIDIA-Omniverse/kit-app-template).
The repo + its docs are the source of truth; this skill is the workflow.

## When to use
Creating/scaffolding an Omniverse Kit application, a Kit extension, a USD
viewer/composer/explorer, or a Kit streaming microservice. For *viewing* an
existing USD scene prefer `omniverse-realtime-viewer`; for asset prep prefer
`omniverse-cad-to-simready`; for scene perf prefer `omniverse-usd-performance-tuning`.

## Mental model
- **Everything is an extension** — uniquely named, versioned packages loaded at
  runtime (Python and/or C++). An *application* is a `.kit` file that composes
  extensions.
- The **Kit SDK** is pulled on first `build` (don't vendor it). Apps render on
  **RTX**; this only runs on an NVIDIA GPU host.

## Preflight (must pass before building)
```bash
nvidia-smi            # an RTX GPU must be present
```
If `nvidia-smi` fails, stop and report: this host can't build/run a Kit app
(author/validate USD instead).

## Workflow
```bash
git clone https://github.com/NVIDIA-Omniverse/kit-app-template
cd kit-app-template

./repo.sh template list                 # see available templates
./repo.sh template new                  # scaffold an app/extension (interactive)
./repo.sh build                         # pulls the Kit SDK + builds (first run is slow)
./repo.sh launch                        # pick the built .kit app to run (RTX window/stream)
./repo.sh test                          # run the app/extension tests
./repo.sh package                       # produce a distributable package
```
On Windows use `repo.bat` with the same subcommands.

### Common templates
- **Kit Base Editor** — minimal editable USD-stage app; best starting point.
- **USD Composer / USD Explorer / USD Viewer** — authoring / browsing / review apps.
- **Kit Service** — headless microservice (e.g. cloud/streaming backends).
- **Streaming** variants — for Omniverse Kit App Streaming to a browser.

### Project layout (after `template new`)
- `source/apps/*.kit` — application definitions (the extensions they load).
- `source/extensions/<name>/` — your extensions (`config/extension.toml`,
  `<py_module>/extension.py`, `premake5.lua` for C++).
- `_build/` — build output (the launchable apps live here).

## Customizing
- Add behavior by creating/editing an **extension** and listing it in the app's
  `.kit` `[dependencies]`, then rebuild.
- Pin the Kit SDK / registry versions in `repo.toml` for reproducible builds.

## Asset prep (OpenUSD) — companion repos
- `usd-exchange` — OpenUSD data-exchange SDK.
- `usd-convert-asset` / `usd-convert-gsplat` — convert 3D formats / Gaussian splats → USD.
- `usd-optimize` — optimize USD for runtime perf/memory.
- `usd-validation-nvidia` — validate USD against NVIDIA + core USD standards.

## Pitfalls
- macOS / CPU-only hosts: build/launch will not render — don't attempt; say so.
- First `build` downloads a lot (Kit SDK + extensions); needs egress + disk.
- Don't hand-edit `_build/`; change `source/` + `.kit`, then rebuild.

## References
- Repo: https://github.com/NVIDIA-Omniverse/kit-app-template
- Kit SDK overview: https://docs.omniverse.nvidia.com/kit/docs/kit-app-template/latest/docs/kit_sdk_overview.html
- OpenUSD: https://developer.nvidia.com/openusd
